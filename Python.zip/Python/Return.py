import SynList
import datetime
'''In this module, the index of book user asked for is passed as parameter along
with contents of the file. Then the quantity of the book is increased and a
Boolean with new contents is returned.'''
def returnBook():
    name=input("Enter borrower name: ")
    z="Borrow-"+name+".txt"
    try:
        with open(z,"r") as th:
            note=th.readlines()
            note=[z.strip("$") for z in note]
    
        with open(z,"r") as th:
            data=th.read()
            print(data)
    except:
        print(" incorrect name *_*")
        returnBook()

    c="Return-"+name+".txt"
    with open(c,"w+")as th:
        th.write("-----------------------------------")
        th.write("------------  Bibliotheca Library Management System--------- \n")
        th.write("----------------------------------------------------------------")
        th.write("Returned By: "+ name+"\n")
        #th.write("    Date: " + datetime.getDate()+"    Time:"+ datetime.getTime()+"\n\n")
        th.write("S.N.\t\tBookname\t\tCost\n")


    total=0.0
    for i in range(len(SynList.bookname)):
        if SynList.bookname[i] in data:
            with open(c,"a") as th:
                th.write(str(i+1)+"\t\t"+SynList.bookname[i]+"\t\t$"+SynList.cost[i]+"\n")
                SynList.quantity[i]=int(SynList.quantity[i])+1
            total+=float(SynList.cost[i])
            
    print("\t\t\t\t"+"$"+str(total))
    print("Is the book return date expired? 0_0")
    print("Press Y and N for the verification")
    net=input()
    if(net.upper()=="Y"):
        print("By how many days was the book returned late?")
        new=int(input())
        se=2*new
        with open(c,"a")as th:
            th.write("\t\t\t\t\tFine: $"+ str(se)+"\n")
        total=total+se
    


    print("Final Total: "+ "$"+str(total))
    with open(c,"a")as th:
        th.write("\t\t\t\t\tTotal: $"+ str(total))
    
        
    with open("books.txt","w+") as th:
            for i in range(len(SynList.bookname)):
                th.write(SynList.bookname[i]+","+SynList.authorname[i]+","+str(SynList.quantity[i])+","+"$"
                +SynList.cost[i]+"\n")
