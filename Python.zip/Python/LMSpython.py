import Return
import SynList
import Borrow
'''This is the main program of the library management system. The main program contains the foundation of the library management system as
the name suggests. It imports from all other modules, call their functions each time whenevernecessary with required parameters and gets requited
details as necessary.'''

def file():
    while(True):
        print("---------------------------------------------------------------------------")
        print("-------- Welcome to the  Bibliotheca library management system-----------    ")
        print("---------------------------------------------------------------------------")
        print("Enter 1.  Display")
        print("Enter 2.  Borrow ")
        print("Enter 3. return ")
        print("Enter 4.  exit")
        try:
            z=int(input("Choose any number from 1-4: "))
            print()
            if(z==1):
                with open("books.txt","r") as th:
                    note=th.read()
                    print(note)
                    print ()
   
            elif(z==2):
                SynList.SynList()
                Borrow.borrowBook()
            elif(z==3):
                SynList.SynList()
                Return.returnBook()
            elif(z==4):
                print("Thank you for borrowing book from us, Hope you have a great day ahead^_^!!")
                break
            else:
                print("enter a valid number 0_0")
        except ValueError:
            print("Please input as suggested.*_*")
file()
