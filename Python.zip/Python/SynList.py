'''This module contains the list of books, their names, the authors of the books ,
quantity and the cost of the book. '''
def SynList():
    global bookname
    global authorname
    global quantity
    global cost
    bookname=[]
    authorname=[]
    quantity=[]
    cost=[]
    with open("books.txt","r") as th:
        note = []  
        read_note = th.readlines()  

        for x in read_note:
           
            remove= x.strip('\n')
            note.append(remove)

        for i in range(len(read_note)):
            grp=0
            for z in note[i].split(','):
                if(grp==0):
                    bookname.append(z)
                elif(grp==1):
                    authorname.append(z)
                elif(grp==2):
                    quantity.append(z)
                elif(grp==3):
                    cost.append(z.strip("$"))
                grp+=1
                    
    

