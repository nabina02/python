import datetime
import SynList
'''In this module, the index of book user asked for is passed
as parameter along with contents of the file. Then the quantity of the book is reduced and
a Boolean with new contents is returned.'''

def borrowBook():
    success=False
    while(True):
        fName=input("Enter the first name of the borrower: ")
        if fName.isalpha():
            break
        print("please input alphabet from A-Z *_*")
    while(True):
        lName=input("Enter the  surname of the borrower: ")
        if lName.isalpha():
            break
        print("please input alphabet from A-Z *_*")
            
    t="Borrow-"+fName+".txt"
    with open(t,"w+") as th:
        th.write(" ---------Bibliotheca Library Management System -------- \n")
        th.write("                   Borrowed By: "+ fName+" "+lName+"\n")
       # th.write("    Date: " + datetime.getDate()+"    Time:"+ datetime.getTime()+"\n\n")
        th.write("S.N. \t\t Bookname \t      Authorname \n")
    
    while success==False:
        print("Please select a option below:")
        for i in range(len(SynList.bookname)):
            print("Enter", i, "to borrow book", SynList.bookname[i])
    
        try:   
            z=int(input())
            try:
                if(int(SynList.quantity[z])>0):
                    print("Books is available. Thank you for borrowing^_^ Have a great day!!")
                    with open(t,"a") as th:
                        th.write("1. \t\t"+ SynList.bookname[z]+"\t\t  "+SynList.authorname[z]+"\n")

                    SynList.quantity[z]=int(SynList.quantity[z])-1
                    with open("books.txt","w+") as th:
                        for i in range(3):
                            th.write(SynList.bookname[i]+","+SynList.authorname[i]+","+str
                            (SynList.quantity[i])+","+"$"+SynList.cost[i]+"\n")


                    #multiple book borrowing code
                    loop=True
                    count=1
                    while loop==True:
                        choice=str(input("Do you want to borrow more books? However you cannot borrow same book twice. Press y for yes and n for no."))
                        if(choice.upper()=="Y"):
                            count=count+1
                            print("Please select an option below:")
                            for i in range(len(SynList.bookname)):
                                print("Enter", i, "to borrow book", SynList.bookname[i])
                            z=int(input())
                            if(int(SynList.quantity[z])>0):
                                print("Book is available^_^ Thank you for borrowing again!!")
                                with open(t,"a") as th:
                                    th.write(str(count) +". \t\t"+ SynList.bookname[z]+"\t\t  "+
                                    SynList.authorname[z]+"\n")

                                SynList.quantity[z]=int(SynList.quantity[z])-1
                                with open("Books.txt","w+") as th:
                                    for i in range(len(SynList.bookname)):
                                        th.write(SynList.bookname[i]+","+SynList.authorname[i]+","+str(SynList.quantity[i])+","+"$"+SynList.cost[i]+"\n")
                                        success=False
                            else:
                                loop=False
                                break
                        elif (choice.upper()=="N"):
                            print ("Thank you for borrowing books from Bibliotheca Library^_^ Hope to see you again!!.^_^ ")
                            print("")
                            loop=False
                            success=True
                        else:
                            print("Please choose as instructed *_*")
                        
                else:
                    print("Books are insufficient 0_0")
                    borrowBook()
                    success=False
            except IndexError:
                print("")
                print("Please choose book according to their number. *_*")
        except ValueError:
            print("")
            print("Please choose as suggested. *_*")
